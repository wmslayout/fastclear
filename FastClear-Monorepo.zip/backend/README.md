# FastClear Backend (FastAPI)

## Local (SQLite) quick start
```bash
cd backend
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
API docs: http://localhost:8000/docs

## Docker + Postgres
```bash
docker compose -f ../infrastructure/docker-compose.yml up --build
```
API will be at http://localhost:8000
