from fastapi import FastAPI, Depends, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy import create_engine, String, Integer, Float, ForeignKey, DateTime, func
from sqlalchemy.orm import sessionmaker, declarative_base, Mapped, mapped_column, relationship, Session
import os

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./fastclear.db")

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {},
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# ------------------- MODELS -------------------
class Officer(Base):
    __tablename__ = "officers"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(120))
    login_id: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    role: Mapped[str] = mapped_column(String(50), default="officer")

class Item(Base):
    __tablename__ = "items"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    description: Mapped[str] = mapped_column(String(255))
    tariff_code: Mapped[str] = mapped_column(String(50), index=True)
    duty_rate: Mapped[float] = mapped_column(Float)  # e.g., 0.15 -> 15%

class Scan(Base):
    __tablename__ = "scans"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    officer_id: Mapped[int] = mapped_column(ForeignKey("officers.id"))
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    quantity: Mapped[int] = mapped_column(Integer, default=1)
    declared_value: Mapped[float] = mapped_column(Float, default=0.0)
    status: Mapped[str] = mapped_column(String(50), default="cleared")  # cleared/flagged/pending
    created_at: Mapped[DateTime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    officer = relationship("Officer")
    item = relationship("Item")

class Flag(Base):
    __tablename__ = "flags"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    scan_id: Mapped[int] = mapped_column(ForeignKey("scans.id"))
    reason: Mapped[str] = mapped_column(String(255))
    created_at: Mapped[DateTime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    scan = relationship("Scan")

# ------------------- SCHEMAS -------------------
class LoginRequest(BaseModel):
    login_id: str

class LoginResponse(BaseModel):
    token: str
    officer_id: int
    name: str
    role: str

class ScanRequest(BaseModel):
    barcode: str | None = None
    tariff_code: str | None = None
    quantity: int = 1
    declared_value: float = 0.0

class ScanResponse(BaseModel):
    scan_id: int
    item_description: str
    tariff_code: str
    duty_rate: float
    computed_duty: float
    status: str

class FlagRequest(BaseModel):
    scan_id: int
    reason: str

# ------------------- APP -------------------
app = FastAPI(title="FastClear API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)
    # Seed minimal data
    with SessionLocal() as db:
        if db.query(Officer).count() == 0:
            db.add_all([
                Officer(name="Officer A", login_id="officer_a", role="officer"),
                Officer(name="Supervisor B", login_id="super_b", role="supervisor"),
            ])
        if db.query(Item).count() == 0:
            db.add_all([
                Item(description="Men's T-Shirt", tariff_code="6109.10", duty_rate=0.15),
                Item(description="Running Shoes", tariff_code="6404.11", duty_rate=0.20),
                Item(description="Smartphone", tariff_code="8517.12", duty_rate=0.05),
            ])
        db.commit()

# ------------------- ROUTES -------------------
@app.post("/auth/login", response_model=LoginResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    officer = db.query(Officer).filter(Officer.login_id == payload.login_id).first()
    if not officer:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = f"fake-token-{officer.id}"  # Replace with JWT for production
    return LoginResponse(token=token, officer_id=officer.id, name=officer.name, role=officer.role)

@app.post("/scan", response_model=ScanResponse)
def process_scan(payload: ScanRequest, db: Session = Depends(get_db)):
    # Accept either a barcode that maps to a tariff_code, or a tariff_code directly.
    tariff_code = payload.tariff_code
    if not tariff_code and payload.barcode:
        # Simple demo mapping (replace with real mapping or lookup table)
        barcode_map = {"000610910": "6109.10", "000640411": "6404.11", "000851712": "8517.12"}
        tariff_code = barcode_map.get(payload.barcode)
        if not tariff_code:
            raise HTTPException(status_code=404, detail="Unknown barcode")

    item = db.query(Item).filter(Item.tariff_code == tariff_code).first()
    if not item:
        raise HTTPException(status_code=404, detail="Tariff not found")

    computed_duty = round(item.duty_rate * payload.declared_value, 2)
    scan = Scan(
        officer_id=1,  # TODO: derive from token
        item_id=item.id,
        quantity=payload.quantity,
        declared_value=payload.declared_value,
        status="pending" if computed_duty == 0 else "cleared",
    )
    db.add(scan)
    db.commit()
    db.refresh(scan)
    return ScanResponse(
        scan_id=scan.id,
        item_description=item.description,
        tariff_code=item.tariff_code,
        duty_rate=item.duty_rate,
        computed_duty=computed_duty,
        status=scan.status,
    )

@app.get("/tariff/{tariff_code}")
def get_tariff(tariff_code: str, db: Session = Depends(get_db)):
    item = db.query(Item).filter(Item.tariff_code == tariff_code).first()
    if not item:
        raise HTTPException(status_code=404, detail="Tariff not found")
    return {
        "description": item.description,
        "tariff_code": item.tariff_code,
        "duty_rate": item.duty_rate,
    }

@app.post("/flags")
def create_flag(payload: FlagRequest, db: Session = Depends(get_db)):
    scan = db.query(Scan).filter(Scan.id == payload.scan_id).first()
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")
    flag = Flag(scan_id=scan.id, reason=payload.reason)
    scan.status = "flagged"
    db.add(flag)
    db.commit()
    return {"ok": True, "flag_id": flag.id}

@app.get("/scans/history/{officer_id}")
def history(officer_id: int, db: Session = Depends(get_db)):
    scans = db.query(Scan).filter(Scan.officer_id == officer_id).order_by(Scan.created_at.desc()).limit(50).all()
    out = []
    for s in scans:
        out.append({
            "scan_id": s.id,
            "created_at": s.created_at.isoformat() if s.created_at else None,
            "status": s.status,
            "item": s.item.description if s.item else None,
            "tariff_code": s.item.tariff_code if s.item else None,
            "quantity": s.quantity,
            "declared_value": s.declared_value,
        })
    return out
