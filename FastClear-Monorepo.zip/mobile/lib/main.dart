import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

const String apiBase = String.fromEnvironment('API_BASE', defaultValue: 'http://10.0.2.2:8000');

void main() {
  runApp(const FastClearApp());
}

class FastClearApp extends StatelessWidget {
  const FastClearApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FastClear',
      theme: ThemeData(useMaterial3: true),
      home: const LoginScreen(),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _controller = TextEditingController(text: 'officer_a');
  bool _loading = false;
  String? _error;

  Future<void> _login() async {
    setState(() { _loading = true; _error = null; });
    try {
      final res = await http.post(Uri.parse('$apiBase/auth/login'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'login_id': _controller.text.trim()}));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('token', data['token']);
        await prefs.setInt('officer_id', data['officer_id']);
        await prefs.setString('name', data['name']);
        if (!mounted) return;
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const ScannerScreen()));
      } else {
        setState(() { _error = 'Login failed'; });
      }
    } catch (e) {
      setState(() { _error = e.toString(); });
    } finally {
      setState(() { _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('FastClear Login')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: const InputDecoration(labelText: 'Officer ID (e.g. officer_a)'),
            ),
            const SizedBox(height: 12),
            if (_error != null) Text(_error!, style: const TextStyle(color: Colors.red)),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _loading ? null : _login,
              child: _loading ? const CircularProgressIndicator() : const Text('Login'),
            )
          ],
        ),
      ),
    );
  }
}

class ScannerScreen extends StatefulWidget {
  const ScannerScreen({super.key});

  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> {
  bool _handling = false;
  String? _resultText;

  Future<void> _handleBarcode(String code) async {
    if (_handling) return;
    setState(() { _handling = true; _resultText = 'Processing $code...'; });
    try {
      final res = await http.post(Uri.parse('$apiBase/scan'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'barcode': code, 'declared_value': 1000, 'quantity': 1}));
      if (res.statusCode == 200) {
        setState(() { _resultText = res.body; });
      } else {
        setState(() { _resultText = 'Error: ${res.body}'; });
      }
    } finally {
      await Future.delayed(const Duration(seconds: 1));
      setState(() { _handling = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scan Shipment')),
      body: Column(
        children: [
          Expanded(
            child: MobileScanner(
              onDetect: (capture) {
                final barcodes = capture.barcodes;
                for (final barcode in barcodes) {
                  final String? raw = barcode.rawValue;
                  if (raw != null) {
                    _handleBarcode(raw);
                    break;
                  }
                }
              },
            ),
          ),
          if (_resultText != null)
            Padding(
              padding: const EdgeInsets.all(12),
              child: Text(_resultText!, maxLines: 6, overflow: TextOverflow.ellipsis),
            ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}
