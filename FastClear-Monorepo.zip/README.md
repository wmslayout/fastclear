# FastClear – NAMRA Smart Scanning App (Monorepo MVP)

This MVP includes:
- **backend/** FastAPI + SQLAlchemy (SQLite by default, PostgreSQL via env)
- **mobile/** Flutter officer app with camera barcode/QR scanning (mobile_scanner)
- **dashboard/** React HQ dashboard (fetches scan history)
- **infrastructure/** Docker Compose for Postgres + API

## Quick Start (fast demo)
1) **Backend (SQLite demo)**
```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open http://localhost:8000/docs

2) **Mobile**
- Open `mobile/` in Android Studio or VS Code with Flutter.
- Run on a device/emulator.
- Ensure API base is reachable (Android emulator uses 10.0.2.2).

3) **Dashboard**
```bash
cd dashboard
npm install
npm run dev
```
Open http://localhost:5173

## Docker (API + Postgres)
```bash
cd infrastructure
docker compose up --build
```

## Notes
- Replace fake login token with JWT in production.
- Integrate real barcode-to-tariff mapping and NAMRA tariff DB.
- Add role-based access, audits, and offline sync for remote posts.
