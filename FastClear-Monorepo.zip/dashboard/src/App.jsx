import React, { useEffect, useState } from 'react'

export default function App(){
  const [rows, setRows] = useState([])
  const [officerId, setOfficerId] = useState(1)

  useEffect(() => {
    fetch(`/api/scans/history/${officerId}`)
      .then(r => r.json())
      .then(setRows)
      .catch(console.error)
  }, [officerId])

  return (
    <div style={{padding: 20, fontFamily: 'sans-serif'}}>
      <h1>FastClear – HQ Dashboard</h1>
      <label>
        Officer ID:
        <input value={officerId} onChange={e => setOfficerId(e.target.value)} style={{marginLeft: 8}}/>
      </label>
      <table border="1" cellPadding="6" cellSpacing="0" style={{marginTop: 12, width: '100%'}}>
        <thead>
          <tr>
            <th>Scan ID</th>
            <th>Date</th>
            <th>Status</th>
            <th>Item</th>
            <th>Tariff</th>
            <th>Qty</th>
            <th>Declared Value</th>
          </tr>
        </thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.scan_id}>
              <td>{r.scan_id}</td>
              <td>{r.created_at}</td>
              <td>{r.status}</td>
              <td>{r.item}</td>
              <td>{r.tariff_code}</td>
              <td>{r.quantity}</td>
              <td>{r.declared_value}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
