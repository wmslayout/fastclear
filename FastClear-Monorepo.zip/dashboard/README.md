# FastClear Dashboard (React + Vite)

## Dev
```bash
cd dashboard
npm install
npm run dev
```
Dashboard will proxy API calls to http://localhost:8000
